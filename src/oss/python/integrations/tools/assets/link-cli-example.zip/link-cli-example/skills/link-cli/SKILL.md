---
name: link-cli
description: Sign the user in to Link and run Stripe's Link CLI as them through the link_login, link_finish_login, link_cli and link_logout tools. Use for any Link, wallet, or payment approval task.
---

# Link CLI through the link tools

Adapted from Stripe's `create-payment-credential` skill
(https://github.com/stripe/link-cli/blob/main/skills/create-payment-credential/SKILL.md).
Here the CLI runs in the sandbox and the tools hold the user's saved session, so
pass only the arguments after `link-cli` to `link_cli`; it adds `--format json`.

## Sign in

1. `link_login`. If `connected`, continue. If `login_required`, show the
   `verification_url` to the user and ask them to complete sign-in there.
2. `link_finish_login`. It waits up to 45 seconds. If `pending`, ask the user to finish
   and call it again. Never ask for codes, tokens or passwords in chat.

Do not run `auth login`, `auth logout`, `onboard` or `demo` through `link_cli`; the
tools refuse them.

## Account checks

```text
link_cli("auth status")
link_cli("user-info retrieve")
link_cli("payment-methods list")
```

`user-info retrieve` may include spend limits (cents; `null` means unlimited) and a
verification requirement with an `action_url` to show the user.

## Request a payment approval

Only after the user agreed to an exact total for a named merchant. `--context` must be
at least 100 characters and describe what is being bought and why. Add `--test` unless
the operator has turned test mode off: test approvals work end to end but issue no card
and charge nothing.

```text
link_cli('spend-request create --amount <cents> --context "<what and why>" --merchant-name "<merchant>" --merchant-url <https url> --test')
```

Show the returned `approval_url` and the amount. After the user says they approved:

```text
link_cli("spend-request retrieve <id>")
```

`approved` is the only status that means approval. `created` and `pending_approval`
mean keep waiting. `denied`, `expired` and `canceled` are final; do not recreate the
request unless the user asks. For `requires_action`, show `display_message` and
`action_url` from `status_details.requires_action.next_action` and stop.

Cancel an unused request at the user's request: `link_cli("spend-request cancel <id>")`.

## Payment credential handoff (live mode only)

This starter does not include a merchant checkout tool. Link approval alone does not
place an order. If no checkout tool has been added, explain that limitation and stop.

When the application supplies a checkout tool, use it for live payment handoff. The
merchant determines whether it needs card details or a supported payment token.
The tool must check the order and fresh Link approval, retrieve the required credential
with `--output-file`, submit to the merchant, and delete the file privately within the
same call. Never retrieve card details or payment tokens through a separate model tool
call or read them with file/shell tools. Report an order as placed only when the
merchant confirms it.
