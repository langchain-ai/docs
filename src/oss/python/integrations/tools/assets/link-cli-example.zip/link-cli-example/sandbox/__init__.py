"""Run Stripe's Link CLI inside the MDA sandbox, signed in with the CLI's own login.

No OAuth client registration: `link-cli auth login` uses Stripe's built-in public
client. The user opens the returned URL, and the CLI keeps the resulting tokens in
its auth file and refreshes them itself. Because a sandbox belongs to one
conversation and is deleted when idle, the authored tools in `tools/link_cli.py`
save each user's auth file in a user-owned Connection between commands. The Store
is an optional local-development fallback.

"""

from managed_deepagents import define_sandbox

sandbox = define_sandbox(
    idle_ttl_seconds=900,
    default_timeout=300,
    proxy_config={
        # Allow Link commands and sign-in, plus npm for CLI installation.
        # This allow list also applies at runtime.
        "access_control": {
            "allow_list": ["api.link.com:443", "login.link.com:443", "registry.npmjs.org:443"]
        },
    },
)
