# Link CLI with Managed Deep Agents

A Python starter for per-user Link sign-in, saved payment methods, and test payment
approvals. The CLI runs in the agent's sandbox. A user-owned Connection preserves
each user's session across conversations.

This is an experimental example. Keep MDA pinned to 0.8.1 because the session helper
uses internal APIs. The sandbox installs Link CLI 0.22.0.

## Setup

Requires Python 3.11 through 3.14, uv, a US LangSmith Cloud workspace with Managed
Deep Agents access, and a Link account with a saved payment method.

From this folder:

```bash
uv sync --frozen
cp .env.example .env
```

Set `OPENAI_API_KEY`, `LANGSMITH_API_KEY`, and `LANGSMITH_WORKSPACE_ID` in `.env`.
Keep `LINK_TEST_MODE=1`, then deploy:

```bash
uv run mda deploy
```

When deployment finishes, open the dashboard URL printed by the CLI and confirm
the deployment is ready. After changing configuration values, deploy again.

The default MDA image used to validate this example included Node.js and npm.
Custom images must include both. The sandbox permits Link hosts and the npm registry over HTTPS.
One allow list applies to setup and runtime, so registry access remains allowed
after installation.

## Try it in Studio

1. Send **Sign me in to Link**, follow the returned URL, and reply **Done**.
   The agent confirms you are signed in.
2. Send **What payment methods do I have?** The agent lists your saved methods.
3. In a new conversation, send **Am I signed in to Link?** The agent confirms
   you are signed in without sending a new link.
4. Request a test approval for an exact amount and merchant. Open the approval URL,
   then ask the agent to check the request's status. Only `approved` confirms approval.

Test mode issues no payment credential and charges nothing. This starter does not
implement merchant checkout or place orders.

## Included files

| File | Purpose |
| --- | --- |
| `agent.py` | Agent definition and registration of the four Link tools. |
| `tools/__init__.py` | Python package marker. |
| `tools/link_cli.py` | Sign-in, commands, sign-out, session storage, and cleanup. |
| `sandbox/__init__.py` | Sandbox settings and network allow list. |
| `sandbox/setup.sh` | Pinned CLI installation. |
| `skills/link-cli/SKILL.md` | CLI commands and approval rules for the agent. |
| `instructions.md` | Agent instructions. |
| `pyproject.toml` and `uv.lock` | Python dependencies and locked versions. |
| `.env.example` | Blank configuration template with test mode enabled. |
| `.gitignore` | Exclusions for local secrets and generated files. |
| `README.md` | Setup and usage instructions. |

## Adapt it

Copy the tools, sandbox files, and skill into an existing MDA project. Merge the
instructions and dependencies, and register `LINK_CLI_TOOLS` alongside your tools.

## Sessions and identity

Link commands can refresh and replace the saved session. The OpenAI example disables
parallel tool calls so the model requests one tool at a time. If you change model
providers, use that provider's equivalent setting. The helper's per-user lock also
serializes Link commands within one server process, including calls from different
conversations.

A custom interface must provide MDA user identity for each person. The helper refuses
requests that have no user identity. Reusing one authenticated identity for multiple
people gives them access to the same saved session.

## Before you go live

Confirm hosted CLI sign-in with Stripe before relying on this starter for a public
product. Before setting `LINK_TEST_MODE=0`, your checkout tool must verify the order and fresh
Link approval. Use card details or a supported payment token as required by the merchant.
Handle the credential privately, delete temporary credential files, and return only
the order result. The agent's file and shell tools can read sandbox files, so a file
alone does not keep payment credentials private from those tools.

The helper attempts cleanup even when saving fails and reports an error if backend
and shell deletion both fail. Session locking is per process; concurrent refreshes
across processes can require sign-in again.
