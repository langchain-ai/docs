from langchain_openai import ChatOpenAI
from managed_deepagents import define_deep_agent

from tools.link_cli import LINK_CLI_TOOLS

# The Link tools run `link-cli` in the sandbox with the user's own saved login.
# Run one tool call per model turn to avoid overlapping Link session refreshes.
agent = define_deep_agent(
    name="link-cli-sandbox",
    model=ChatOpenAI(
        model="gpt-5.6-sol",
        use_responses_api=True,
        model_kwargs={"parallel_tool_calls": False},
    ),
    tools=LINK_CLI_TOOLS,
)
